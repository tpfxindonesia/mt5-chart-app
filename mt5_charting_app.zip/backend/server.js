const express = require('express');
const cors = require('cors');
const { getOHLC } = require('./mt5/connector');
require('dotenv').config();

const app = express();
app.use(cors());

app.get('/history', async (req, res) => {
  const { symbol, from, to, resolution } = req.query;
  try {
    const data = await getOHLC(symbol, parseInt(from), parseInt(to), resolution);
    const rsp = { s: 'ok', t: [], o: [], h: [], l: [], c: [], v: [] };
    data.forEach(b => {
      rsp.t.push(b.time); rsp.o.push(b.open); rsp.h.push(b.high); rsp.l.push(b.low);
      rsp.c.push(b.close); rsp.v.push(b.volume);
    });
    res.json(rsp);
  } catch (e) {
    res.json({ s: 'error', errmsg: e.message });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Backend running on :${port}`));