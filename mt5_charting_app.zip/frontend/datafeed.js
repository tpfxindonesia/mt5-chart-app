const Datafeed = {
  onReady:cb=>cb({supported_resolutions:["1","5","15","30","60","240","1D"]}),
  resolveSymbol:(n,cb)=>cb({name:n,ticker:n,session:"24x7",timezone:"Etc/UTC",pricescale:100000,minmov:1,has_intraday:true,supported_resolutions:["1","5","15","30","60","240","1D"],volume_precision:1,data_status:"streaming"}),
  getBars:async(s,r,f,t,h,e)=>{try{const u=`https://mt5-backend-production.up.railway.app/history?symbol=${s.name}&resolution=${r}&from=${f}&to=${t}`;const j=await fetch(u).then(x=>x.json());if(j.s!=='ok'){h([],{noData:true});return;}const b=j.t.map((q,i)=>({time:q*1000,open:j.o[i],high:j.h[i],low:j.l[i],close:j.c[i],volume:j.v[i]}));h(b,{noData:!b.length});}catch(c){e(c);}},
  subscribeBars:()=>{},unsubscribeBars:()=>{}
};